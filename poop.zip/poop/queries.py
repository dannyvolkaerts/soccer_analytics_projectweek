import psycopg2
import dotenv
import os
import pandas as pd

# Load environment variables
dotenv.load_dotenv()

# Database connection parameters
PG_PASSWORD = os.getenv("PG_PASSWORD")
PG_USER = os.getenv("PG_USER")
PG_HOST = os.getenv("PG_HOST")
PG_PORT = os.getenv("PG_PORT")
PG_DATABASE = os.getenv("PG_DB")

# Connect to the database
def get_connection():
    return psycopg2.connect(
        host=PG_HOST,
        database=PG_DATABASE,
        user=PG_USER,
        password=PG_PASSWORD,
        port=PG_PORT,
        sslmode="require",
    )

# SQL queries
# PLEASE MAKE IT CUSTOMIZABLE SOON HAL THIS IS BAD
BALL_QUERY = """
SELECT pt.period_id, pt.frame_id, pt.timestamp, pt.x, pt.y, pt.player_id, p.team_id
FROM player_tracking pt
JOIN players p ON pt.player_id = p.player_id
JOIN teams t ON p.team_id = t.team_id
WHERE pt.game_id = '5uts2s7fl98clqz8uymaazehg' AND p.player_id = 'ball' AND pt.period_id = 1
ORDER BY timestamp;
"""

TEAM_QUERY = """
SELECT DISTINCT p.team_id
FROM player_tracking pt
JOIN players p ON pt.player_id = p.player_id
JOIN teams t ON p.team_id = t.team_id AND p.player_id != 'ball'
WHERE pt.game_id = '5uts2s7fl98clqz8uymaazehg';
"""

TEAM_QUERIES = """
SELECT pt.frame_id, pt.timestamp, pt.player_id, pt.x, pt.y, p.team_id
FROM player_tracking pt
JOIN players p ON pt.player_id = p.player_id
JOIN teams t ON p.team_id = t.team_id
WHERE pt.game_id = '5uts2s7fl98clqz8uymaazehg' AND p.player_id != 'ball' AND p.team_id = %s
ORDER BY timestamp;
"""

# Load data from the database
def load_data():
    conn = get_connection()
    team_ids_df = pd.read_sql_query(TEAM_QUERY, conn)
    team_ids = team_ids_df['team_id'].tolist()

    df_ball = pd.read_sql_query(BALL_QUERY, conn)
    df_home = pd.read_sql_query(TEAM_QUERIES, conn, params=(team_ids[0],))
    df_away = pd.read_sql_query(TEAM_QUERIES, conn, params=(team_ids[1],))

    conn.close()
    return df_ball, df_home, df_away